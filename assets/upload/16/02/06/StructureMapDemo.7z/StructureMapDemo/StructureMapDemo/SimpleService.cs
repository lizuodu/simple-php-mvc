﻿using System;

namespace StructureMapDemo
{
    public class SimpleService : ISimpleService
    {
        public void DoSimple()
        {
            Console.WriteLine("Hello IoC");
        }
    }
}