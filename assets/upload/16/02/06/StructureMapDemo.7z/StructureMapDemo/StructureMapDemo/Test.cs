﻿namespace StructureMapDemo
{
    public class Test
    {
        private ISimpleService _simple;

        public Test()
        {
            // 从容器中获取实例
            this._simple = Program.container.GetInstance<ISimpleService>();
        }

        public void PrintHello()
        {
            this._simple.DoSimple();
        }
    }
}