﻿using StructureMap;
using System;

namespace StructureMapDemo
{
    internal class Program
    {
        public static IContainer container;

        private static void Main(string[] args)
        {
            InitIoC();

            Test test = new Test();
            test.PrintHello();

            Console.ReadLine();
        }

        private static void InitIoC()
        {
            // 创建容器
            container = new Container(m =>
            {
                // 添加映射
                m.For(typeof(ISimpleService)).Use(typeof(SimpleService));
            });
            // 为Test类型注入
            // 在MVC中则可以创建一个继承自System.Web.Mvc.DefaultControllerFactory的控制器工厂XXControllerFactory，
            // 使用 ControllerBuilder.Current.SetControllerFactory(new XXControllerFactory())自动来为每个控制器类注入
            container.GetInstance(typeof(Test));
        }
    }
}