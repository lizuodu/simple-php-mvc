﻿namespace StructureMapDemo
{
    public interface ISimpleService
    {
        void DoSimple();
    }
}