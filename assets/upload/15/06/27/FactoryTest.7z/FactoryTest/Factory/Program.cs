﻿using Factory.BLL;
using Factory.IBLL;
using System;

namespace Factory
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            IFactory factory = new SQLiteProductFactory();
            IProduct product = factory.GetInstance();
            Console.WriteLine(product.GetProduct());
            Console.ReadKey();
        }
    }
}