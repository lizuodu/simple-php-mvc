﻿namespace Factory.IBLL
{
    public interface IFactory
    {
        IProduct GetInstance();
    }
}