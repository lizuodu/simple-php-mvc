﻿namespace Factory.Model
{
    public class Product
    {
        public string ProductName { get; set; }

        public override string ToString()
        {
            return string.Format("产品类型：{0}", ProductName);
        }
    }
}