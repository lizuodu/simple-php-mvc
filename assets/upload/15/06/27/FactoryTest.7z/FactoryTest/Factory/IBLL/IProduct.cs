﻿using Factory.Model;

namespace Factory.IBLL
{
    public interface IProduct
    {
        Product GetProduct();
    }
}