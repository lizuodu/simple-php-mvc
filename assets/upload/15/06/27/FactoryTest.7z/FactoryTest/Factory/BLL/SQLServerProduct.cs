﻿using Factory.IBLL;
using Factory.Model;

namespace Factory.BLL
{
    public class SQLServerProduct : IProduct
    {
        public Product GetProduct()
        {
            return new Product() { ProductName = "SQLServer产品" };
        }
    }
}