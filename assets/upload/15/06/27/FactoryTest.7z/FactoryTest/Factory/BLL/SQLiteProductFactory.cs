﻿using Factory.IBLL;

namespace Factory.BLL
{
    public class SQLiteProductFactory : IFactory
    {
        public IProduct GetInstance()
        {
            return new SQLiteProduct();
        }
    }
}