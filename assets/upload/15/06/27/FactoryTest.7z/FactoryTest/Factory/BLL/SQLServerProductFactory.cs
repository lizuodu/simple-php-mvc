﻿using Factory.IBLL;

namespace Factory.BLL
{
    public class SQLServerProductFactory : IFactory
    {
        public IProduct GetInstance()
        {
            return new SQLServerProduct();
        }
    }
}