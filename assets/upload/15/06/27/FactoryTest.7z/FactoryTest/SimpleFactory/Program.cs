﻿using SimpleFactory.BLL;
using SimpleFactory.IBLL;
using System;

namespace SimpleFactory
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            IProduct product = ProductFactory.GetInstance("SQLite");
            Console.WriteLine(product.GetProduct());
            Console.ReadKey();
        }
    }
}