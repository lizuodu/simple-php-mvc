﻿using SimpleFactory.IBLL;
using SimpleFactory.Model;

namespace SimpleFactory.BLL
{
    public class SQLiteProduct : IProduct
    {
        public Product GetProduct()
        {
            return new Product() { ProductName = "SQLite产品" };
        }
    }
}