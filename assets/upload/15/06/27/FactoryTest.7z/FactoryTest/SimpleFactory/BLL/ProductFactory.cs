﻿using SimpleFactory.IBLL;

namespace SimpleFactory.BLL
{
    public class ProductFactory
    {
        public static IProduct GetInstance(string type)
        {
            if (type == "SQLServer")
            {
                return new SQLServerProduct();
            }
            else if (type == "SQLite")
            {
                return new SQLiteProduct();
            }
            return null;
        }
    }
}