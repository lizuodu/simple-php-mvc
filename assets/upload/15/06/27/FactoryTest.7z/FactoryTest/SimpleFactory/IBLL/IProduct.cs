﻿using SimpleFactory.Model;

namespace SimpleFactory.IBLL
{
    public interface IProduct
    {
        Product GetProduct();
    }
}