﻿namespace AutoMapperTest.Entity
{
    public class ProductsDto
    {
        /// <summary>
        /// 商品编号
        /// </summary>
        public int PID { get; set; }

        /// <summary>
        /// 商品名称
        /// </summary>
        public string PName { get; set; }

        /// <summary>
        /// 规格
        /// </summary>
        public string QPUnit { get; set; }

        /// <summary>
        /// 单价
        /// </summary>
        public decimal UPrice { get; set; }

        /// <summary>
        /// 库存
        /// </summary>
        public int UIStock { get; set; }
    }
}