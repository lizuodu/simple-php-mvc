﻿using AutoMapperTest.Entity;
using System;
using System.Collections.Generic;

namespace AutoMapperTest
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码、svc 和配置文件中的类名“Service1”。
    // 注意: 为了启动 WCF 测试客户端以测试此服务，请在解决方案资源管理器中选择 Service1.svc 或 Service1.svc.cs，然后开始调试。
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public List<Products> GetAllProducts()
        {
            List<Products> list = DAL.GetAllProducts();
            return list;
        }

        // 获取所有商品
        public List<ProductsDto> GetAllProductsDto()
        {
            List<Products> list = DAL.GetAllProducts();

            AutoMapper.Mapper.CreateMap<Products, ProductsDto>().
                ForMember(t => t.PID, r => r.MapFrom(s => s.ProductID)).
                ForMember(t => t.PName, r => r.MapFrom(s => s.ProductName)).
                ForMember(t => t.QPUnit, r => r.MapFrom(s => s.QuantityPerUnit)).
                ForMember(t => t.UPrice, r => r.MapFrom(s => s.UnitPrice)).
                ForMember(t => t.UIStock, r => r.MapFrom(s => s.UnitsInStock));

            var dtoList = AutoMapper.Mapper.Map<List<ProductsDto>>(list);
            return dtoList;
        }
    }
}