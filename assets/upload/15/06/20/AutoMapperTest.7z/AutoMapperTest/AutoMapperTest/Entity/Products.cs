﻿namespace AutoMapperTest.Entity
{
    public class Products
    {
        /// <summary>
        /// 商品编号
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 规格
        /// </summary>
        public string QuantityPerUnit { get; set; }

        /// <summary>
        /// 单价
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// 库存
        /// </summary>
        public int UnitsInStock { get; set; }

        /// <summary>
        /// 总价
        /// </summary>
        /// <param name="count">个数</param>
        /// <returns></returns>
        public decimal SumPrice(int count)
        {
            return UnitPrice * count;
        }
    }
}