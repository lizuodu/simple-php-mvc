﻿using AutoMapperTest.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AutoMapperTest
{
    public class DAL
    {
        protected static readonly string ConnectionString = "server=.;database=Northwind;uid=sa;pwd=123456;";

        public static List<Products> GetAllProducts()
        {
            string SQL = "SELECT ProductID,ProductName,QuantityPerUnit,UnitPrice,UnitsInStock FROM dbo.Products(NOLOCK);";
            List<Products> list = null;
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = SQL;
                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    AutoMapper.Mapper.CreateMap<SqlDataReader, List<Products>>();
                    list = AutoMapper.Mapper.Map<List<Products>>(dr);
                }
            }
            return list;
        }
    }
}