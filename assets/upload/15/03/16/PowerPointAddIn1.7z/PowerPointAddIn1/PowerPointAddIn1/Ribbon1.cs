﻿using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Office.Tools.Ribbon;
using Office = Microsoft.Office.Core;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;

namespace PowerPointAddIn1
{
    /// <summary>
    /// 程序暂时这样写，现在没有时间了，以后可关注
    /// http://lizuodu.com/post/show/id/31
    /// </summary>
    public partial class Ribbon1
    {
        private PowerPoint.Shape Label;
        public Thread ElapseTh;
        public Thread SetLabelTh;
        public List<PowerPoint.Shape> LabelList; // 所有的Label
        public int ElapsedCounter = 0;
        public bool FirstStart = true;

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            LabelList = new List<PowerPoint.Shape>();
            this.SetButtonState(false);
        }

        private void btnStart_Click(object sender, RibbonControlEventArgs e)
        {
            if (FirstStart)
            {
                // 设置Label线程
                ThreadStart SetLabelTs = new ThreadStart(SetLabel);
                SetLabelTh = new Thread(SetLabelTs);
                SetLabelTh.Start();
            }

            ParameterizedThreadStart ElapsePts = new ParameterizedThreadStart(UpdateLabelElapse);
            ElapseTh = new Thread(ElapsePts);
            ElapseTh.Start(LabelList);

            FirstStart = false;

            this.SetButtonState(true);
        }

        /// <summary>
        /// 为当前PTT的所有页面添加一个显示时间的Label
        /// </summary>
        private void SetLabel()
        {
            PowerPoint.Slides ss = Globals.ThisAddIn.Application.ActivePresentation.Slides;
            if (LabelList.Count > 0) LabelList.Clear();
            for (int i = 1; i <= ss.Count; i++)// 遍历该文档集合,添加文本框
            {
                PowerPoint.Slide slide = ss[i];
                Label = slide.Shapes.AddLabel(Office.MsoTextOrientation.msoTextOrientationHorizontal, 10, 10, 600, 50);// 向当前PPT添加文本框
                // Label.TextFrame.TextRange.Text = ElapsedTime.ToString("yyyy-MM-dd HH:mm:ss");// 设置文本框的内容
                // Label.TextFrame.TextRange.Font.Size = 48;// 设置文本字体大小
                // Label.TextFrame.TextRange.Font.Color.RGB = Color.DarkViolet.ToArgb();// 设置文本颜色
                LabelList.Add(Label);
            }
        }

        private void UpdateLabelElapse(object s)
        {
            List<PowerPoint.Shape> List = (List<PowerPoint.Shape>)s;
            try
            {
                while (true)
                {
                    int Second = ElapsedCounter > 60 ? ElapsedCounter % 60 : ElapsedCounter;
                    int Minutes = (ElapsedCounter / 60) > 60 ? (ElapsedCounter / 60) % 60 : (ElapsedCounter / 60);
                    string ElapsedTime = Minutes.ToString("00") + ":" + Second.ToString("00");
                    for (int i = 0; i < List.Count; i++)
                    {
                        List[i].TextFrame.TextRange.Text = ElapsedTime;
                    }
                    Thread.Sleep(1000);
                    ElapsedCounter++;
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void btnStop_Click(object sender, RibbonControlEventArgs e)
        {
            ElapseTh.Abort();
            this.SetButtonState(false);
        }

        public void SetButtonState(bool isStart)
        {
            if (isStart)
            {
                this.btnStart.Enabled = false;
                this.btnStop.Enabled = true;
            }
            else
            {
                this.btnStart.Enabled = true;
                this.btnStop.Enabled = false;
            }
        }
    }
}