﻿using System.Collections.Generic;

namespace AdapterTest.Way1
{
    public class Product
    {
        /// <summary>
        /// 商品ID
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 商品单价
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// 获取所有的商品
        /// </summary>
        /// <returns></returns>
        public List<Product> GetProduct() 
        {
            return new List<Product>();
        }

        /// <summary>
        /// 获取一个商品
        /// </summary>
        /// <param name="id">商品ID</param>
        /// <returns></returns>
        public Product GetProduct(int id) 
        {
            return new Product() { ID = id, Name = "TestA", Price = 10 };
        }

        /// <summary>
        /// 删除一个商品
        /// </summary>
        /// <param name="id">商品编号</param>
        /// <returns></returns>
        public bool DeleteProduct(int id)
        {
            return true;
        }

    }
}
