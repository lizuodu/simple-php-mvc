﻿using System.Collections.Generic;

namespace AdapterTest.Way2
{
    public interface IProduct
    {
        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="name">商品名称</param>
        /// <returns></returns>
        public List<Product> GetProduct(string name);
    }
}
