﻿using System.Collections.Generic;
/**
 * 商品适配器
 */
namespace AdapterTest.Way1
{
    public class ProductAdapter : Product, IProduct
    {
        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="name">商品名称</param>
        /// <returns></returns>
        public List<Product> GetProduct(string name)
        {
            return new List<Product>();
        }

    }
}
