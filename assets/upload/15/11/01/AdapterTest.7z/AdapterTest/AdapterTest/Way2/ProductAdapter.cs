﻿using System;
using System.Collections.Generic;

namespace AdapterTest.Way2
{
    public class ProductAdapter : IProduct
    {
        private Product product;

        public ProductAdapter(Product product)
        {
            this.product = product;
        }

        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="name">商品名称</param>
        /// <returns></returns>
        public List<Product> GetProduct(string name)
        {
            return new List<Product>() { 
                new Product() { ID = 1, Name = name, Price = 10 }
            };
        }

        /// <summary>
        /// 获取所有的商品
        /// </summary>
        /// <returns></returns>
        public List<Product> GetProduct()
        {
            return product.GetProduct();
        }

        /// <summary>
        /// 获取一个商品
        /// </summary>
        /// <param name="id">商品ID</param>
        /// <returns></returns>
        public Product GetProduct(int id)
        {
            return product.GetProduct(id);
        }

        /// <summary>
        /// 删除一个商品
        /// </summary>
        /// <param name="id">商品编号</param>
        /// <returns></returns>
        public bool DeleteProduct(int id)
        {
            return product.DeleteProduct(id);
        }

    }
}
