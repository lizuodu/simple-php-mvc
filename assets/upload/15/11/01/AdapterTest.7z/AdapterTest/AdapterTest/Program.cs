﻿// using AdapterTest.Way1;
using AdapterTest.Way2;

namespace AdapterTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // 未使用适配器
            //Product product = new Product();
            //product.GetProduct();

            // 使用类适配器
            //ProductAdapter adapter = new ProductAdapter();
            //adapter.GetProduct();
            //adapter.GetProduct("");

            // 使用对象适配器
            ProductAdapter adapter = new ProductAdapter(new Product());
            adapter.GetProduct("");


        }
    }
}
