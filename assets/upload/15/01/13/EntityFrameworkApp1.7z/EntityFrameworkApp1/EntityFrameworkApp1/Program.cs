﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;

namespace EntityFrameworkApp1
{
    internal class Program
    {
        public static ProductDbContext Db = new ProductDbContext();

        private static void Main(string[] args)
        {
            //重新设置宏DataDirectory，请参看我的博客
            string AppDataDic = AppDomain.CurrentDomain.BaseDirectory;
            AppDataDic = Path.Combine(AppDataDic + "../../App_Data/");
            DirectoryInfo DicInfo = new DirectoryInfo(AppDataDic);
            AppDataDic = DicInfo.FullName;
            AppDomain.CurrentDomain.SetData("DataDirectory", AppDataDic);

            Product Model = new Product() { Name = "AA", Price = 9 };

            //将Product的对象加入EF管理容器，并获取伪包装类
            DbEntityEntry<Product> Entry = Db.Entry<Product>(Model);

            //设置包装类对象状态为新增
            Entry.State = System.Data.Entity.EntityState.Added;

            //保存到数据库
            Db.SaveChanges();

            //遍历集合
            List<Product> Products = Db.Product.ToList();
            Products.ForEach(
                item => Console.WriteLine(item.ID + " " + item.Name + " " + item.Price));

            Console.ReadKey();
        }
    }
}