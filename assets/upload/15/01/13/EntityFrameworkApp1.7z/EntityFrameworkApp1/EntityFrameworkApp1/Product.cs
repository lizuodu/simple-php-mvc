﻿using System.Data.Entity;

namespace EntityFrameworkApp1
{
    /// <summary>
    /// 商品类
    /// </summary>
    public class Product
    {
        /// <summary>
        /// 商品编号
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 商品名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 商品价格
        /// </summary>
        public decimal Price { get; set; }
    }

    public class ProductDbContext : DbContext
    {
        public ProductDbContext()
            : base("name=ProductDbContext")
        {
        }

        /// <summary>
        /// Product集合
        /// </summary>
        public DbSet<Product> Product { get; set; }
    }
}