﻿using Patterns.Test.UseIoC.Model;
using System.Collections.Generic;

namespace Patterns.Test.UseIoC.Repository
{
    public interface IProductReponsitory
    {
        IList<Product> GetAllProductsIn(int productID);
    }
}