﻿using Patterns.Test.UseIoC.Cache;
using Patterns.Test.UseIoC.Model;
using Patterns.Test.UseIoC.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Test.UseIoC.Service
{
    public class ProductService
    {
        private IProductReponsitory _productRepository;
        private ICacheStorage _cacheStorage;

        public ProductService(IProductReponsitory productReponsitory,
            ICacheStorage cacheStorage)
        {
            // 使用构造函数方式传递接口进行注入
            _productRepository = productReponsitory;
            _cacheStorage = cacheStorage;
        }

        public List<Product> GetAllProductsIn(int productID)
        {
            IList<Product> products = null;
            string cacheID = string.Format("products{0}", productID);
            // 使用适配器模式来实现缓存
            products = _cacheStorage.ReTrive<IList<Product>>(cacheID);
            if (products == null)
            {
                products = _productRepository.GetAllProductsIn(productID);
                _cacheStorage.Store(cacheID, products);
            }
            return products as List<Product>;
        }
    }
}