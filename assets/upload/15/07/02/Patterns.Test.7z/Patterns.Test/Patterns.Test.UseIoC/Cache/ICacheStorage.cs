﻿namespace Patterns.Test.UseIoC.Cache
{
    public interface ICacheStorage
    {
        void Remove(string key);

        void Store(string key, object value);

        T ReTrive<T>(string key);
    }
}