﻿namespace Patterns.Test.UseIoC.Cache
{
    public class NullCacheAdapter : ICacheStorage
    {
        public void Remove(string key)
        {
        }

        public void Store(string key, object value)
        {
        }

        public T ReTrive<T>(string key)
        {
            return default(T);
        }
    }
}