﻿using Patterns.Test.UseIoC.Cache;
using Patterns.Test.UseIoC.Model;
using Patterns.Test.UseIoC.Repository;
using Patterns.Test.UseIoC.Service;
using System;
using System.Collections.Generic;

namespace Patterns.Test.UseIoC
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //不实现缓存则注入Null Object
            //ProductService productService = new ProductService(
            //    new ProductReponsitory(),
            //    new NullCacheAdapter());

            ProductService productService = new ProductService(
                new ProductReponsitory(),
                new HashtableCacheAdapter());

            List<Product> products = productService.GetAllProductsIn(3);
            products.ForEach(
                p =>
                Console.WriteLine("商品编号：" + p.ProductID + " 商品名称：" + p.ProductName)
                );
            Console.ReadKey();
        }
    }
}