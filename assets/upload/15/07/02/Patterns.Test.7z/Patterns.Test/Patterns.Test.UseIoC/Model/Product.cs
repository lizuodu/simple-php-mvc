﻿namespace Patterns.Test.UseIoC.Model
{
    public class Product
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }
    }
}