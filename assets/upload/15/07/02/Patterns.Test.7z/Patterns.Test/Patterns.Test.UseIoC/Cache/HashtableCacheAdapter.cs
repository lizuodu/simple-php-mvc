﻿using System.Collections;

namespace Patterns.Test.UseIoC.Cache
{
    public class HashtableCacheAdapter : ICacheStorage
    {
        private Hashtable _cache = new Hashtable();

        public void Remove(string key)
        {
            _cache.Remove(key);
        }

        public void Store(string key, object value)
        {
            _cache.Add(key, value);
        }

        public T ReTrive<T>(string key)
        {
            T item = default(T);
            foreach (DictionaryEntry i in _cache)
            {
                if (i.Key == key)
                {
                    item = (T)i.Value;
                }
            }
            return item;
        }
    }
}