﻿using Patterns.Test.NotUseIoC.Model;
using Patterns.Test.NotUseIoC.Reponsitory;
using System.Collections;
using System.Collections.Generic;

namespace Patterns.Test.NotUseIoC.Service
{
    public class ProductService
    {
        private ProductReponsitory _productReponsitory;

        private Hashtable _cache = new Hashtable();

        public ProductService()
        {
            _productReponsitory = new ProductReponsitory();
        }

        public IList<Product> GetAllProductsIn(int productID)
        {
            IList<Product> products = null;
            string cacheID = string.Format("products{0}", productID);
            foreach (DictionaryEntry item in _cache)
            {
                if (item.Key == cacheID)
                {
                    products = item.Value as List<Product>;
                }
            }

            if (products == null)
            {
                products = _productReponsitory.GetAllProductsIn(productID);
                _cache.Add(cacheID, products);
            }

            return products;
        }
    }
}