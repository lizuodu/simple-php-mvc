﻿using System;

namespace Patterns.Test.NotUseIoC.Model
{
    public class Product
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }
    }
}