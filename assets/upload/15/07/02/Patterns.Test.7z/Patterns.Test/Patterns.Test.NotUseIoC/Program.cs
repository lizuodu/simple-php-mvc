﻿using Patterns.Test.NotUseIoC.Model;
using Patterns.Test.NotUseIoC.Service;
using System;
using System.Collections.Generic;

namespace Patterns.Test.NotUseIoC
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            IList<Product> products = new ProductService().GetAllProductsIn(4);
            foreach (var item in products)
            {
                Console.WriteLine("商品编号：" + item.ProductID + " 商品名称：" + item.ProductName);
            }
            Console.ReadKey();
        }
    }
}