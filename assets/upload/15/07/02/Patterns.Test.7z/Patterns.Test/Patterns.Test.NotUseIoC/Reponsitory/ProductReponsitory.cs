﻿using Patterns.Test.NotUseIoC.Model;
using System.Collections.Generic;

namespace Patterns.Test.NotUseIoC.Reponsitory
{
    public class ProductReponsitory
    {
        public IList<Product> GetAllProductsIn(int productID)
        {
            List<Product> products = new List<Product>();
            products.Add(new Product() { ProductID = 1, ProductName = "铅笔" });
            products.Add(new Product() { ProductID = 2, ProductName = "钢笔" });
            products.Add(new Product() { ProductID = 3, ProductName = "毛笔" });
            products.Add(new Product() { ProductID = 4, ProductName = "圆珠笔" });
            return products.FindAll(r => r.ProductID == productID);
        }
    }
}